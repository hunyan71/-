# health-code-simulator

## Installation

```shell
npm install
```

## Development

```shell
npm run dev

# develop with https server
npm run dev:https
```

## Build

### Build for production

```shell
npm run build
```
